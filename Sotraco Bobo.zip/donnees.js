                              
                  
    const donneesSotraco = {
      "lignes": [
        {
          "code_ligne": "L1", "nom": "Ligne N°1",
          "depart": "Cité Verte de Belleville (CROUB)", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Cité verte de Belleville", "Restaurant", "Centre culturel René-Fournier", "Station Sobucop", "Lycée National", "Pharmacie Hayat", "Station Shell", "CRHB", "Lycée La Sagesse", "Pharmacie Bethel", "Station Ski", "Caisse populaire de Colsama", "Marché de fruits", "Commissariat du 6ème arrondissement", "BCEAO", "Gare Rahimo", "CHU Sourou SANOU", "Dr SONABEL", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L2", "nom": "Ligne N°2",
          "depart": "Secteurs 24 & 25 (route de Ouaga)", "terminus": "Place Tiéfo Amoro",
          "arrets": ["Terminus Station Orix rte de Ouaga", "Station Oil Libya", "Station Total", "Station Shell", "Ecobank Sarfalao", "Station Petrofa route de Ouaga", "Gare Rakieta route de Ouaga", "Café Neerwaya", "Église de Ouezzinville", "Sonapost Koko", "Mosquée de Ouezzinville", "Station Shell Bindougousso", "Collège de Tourouma", "Marché de Farakan", "CSPS de Hamdalaye", "Station Total Hamdalaye", "Terminus Tiéfo Amoro"]
        },
        {
          "code_ligne": "L2B", "nom": "Ligne N°2B ",
          "depart": "Marché de Yéguéréssio / Secteurs 24 & 25", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Marché de Yéguéréssio", "Avenue de l'Union Européenne", "Station Orix", "Station Total", "Ecobank Sarfalao", "Gare Rakieta", "Café Neerwaya", "Église de Ouezzinville", "Sonapost Koko", "Mosquée de Ouezzinville", "Station Shell Bindougousso", "Collège de Tourouma", "Marché de Farakan", "CSPS de Hamdalaye", "Place du Paysan", "Monument de la CAF", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L3", "nom": "Ligne N°3",
          "depart": "Station Petro Sar route de Bama", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Station PetroSar route de Bama", "Station service de la cité", "SONATUR Bobo", "Boulangerie Apiou", "Marché de Yéguéré", "Boulangerie Wend Konta", "Lycée Notre Dame de la Providence", "CNRST", "Commissariat de police Houet", "Arrondissement N°1", "Apsonic Moto", "Sonapost Hamdalaye", "Total SITARAIL", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L4", "nom": "Ligne N°4",
          "depart": "Secteurs 24 & 25 (Route de Ouaga)", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Station Orix", "Station Oil Lybia", "Ecobank Sarfalao", "Gare Rakieta", "Lycée Ouezzin Coulibaly", "Restaurant Cross Road", "Pharmacie Dafra", "Boulangerie Terra", "Ciné Guimbi Ouattara", "Lycée El Kana", "Stade Wobi", "CSPS de Hamdalaye", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L5", "nom": "Ligne N°5",
          "depart": "Dépôt Pharmaceutique de Farako-Ba", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Dépôt pharmaceutique de Farako-Ba", "Matourkou", "DR SONABEL", "DR LONAB", "RTB 2", "Cimetière municipal", "BRAKINA", "CAMEG", "SOFITEX", "Pharmacie St Raphaël", "SONACEB", "Zone industrielle", "Lycée Pr Joseph Ki-Zerbo", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L6", "nom": "Ligne N°6",
          "depart": "Terminus Djoulankolo-logo", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Terminus Djoulankolo-logo", "Hôtel la Consolatrice", "Centre Médical Saint-Bernard", "Station Total Bindougousso", "Marché de Bindougousso", "Librairie Sawadogo", "Collège Tounouma", "Marché De Farakan", "Mosquée de Farakan", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L7B", "nom": "Ligne N°7B",
          "depart": "Station Amira Oil de Sakabi / CSPS Santidougou", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Station Amira Oil", "Station Shell de Sakabi", "Mosquée de Hamdalaye", "Alimentation BS", "Lycée Privé le Messager", "Pharmacie N. Gouba", "Pharmacie Rélwende", "Apollo", "CSPS Hamdalaye", "Cathédrale ND de Lourdes", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L8", "nom": "Ligne N°8",
          "depart": "Djoulankolo-logo", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Djoulankolo-logo", "CSPS Saint Bernard", "Station Excel", "Mosquée Ouezzinville", "Gare Rakieta", "ENEP", "Maison de la culture", "Rond-point du Cinquantenaire", "UCAO", "Foyer du Sapeur", "Palais de justice", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L9", "nom": "Ligne N°9",
          "depart": "Stade Lamizana", "terminus": "Zone des Écoles / Place Tiéfo AMORO",
          "arrets": ["Stade Lamizana", "Amphi de 22", "SNC", "CMA de Do Aprosar", "Plateau de Yéguéré", "Pharmacie Vitalis", "Lycée mixte d'Accart-Ville", "Station Ski", "Club Sonabel", "Brigade de Gendarmerie", "Place Tiéfo Amoro", "Institut Français", "Théâtre de l'Amitié", "Zone des Ecoles"]
        },
        {
          "code_ligne": "L10", "nom": "Ligne N°10",
          "depart": "Huilerie de Samagan", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Huilerie de Samagan", "Samagan", "LNBTP", "Lycée privé Maxwell", "Château d'eau de Lafiabougou", "Pharmacie Harmonie", "Palais de Justice", "Marché de Fruits", "Commissariat du 6ème Arrondissement", "Place Tiéfo Amoro"]
          },
  {
    "code_ligne": "L18",
    "nom": "Ligne N°18",
    "depart": "Place Tiéfo Amoro",
    "terminus": "UCAO",
    "arrets": [
      "Place Tiéfo Amoro",
      "UCAO"
    ],
    "fichier": "ligne18.html"
  },
  {
    "code_ligne": "L11",
 "nom": "Ligne N°11",
          "depart": "INSSA", "terminus": "UCAO",
          "arrets": ["Terminal UCAO", "Rondpoint du cinquantenaiere", "Av. Leauveau", "Sapeur pompier", "Rondpoint place de la Nation", "Av. de la Nation", "LONAB", "Place Tiefo Amoro", "AV. de l'Unité", "BCEAO", "AV. de l'Independance", "BRAKINA", "Rondpoint Blaise Khadafi", "Rue 20.07", "Trigone", "Station Total Colsama", "Pharmacie Mah TA", "Terminal INSSA"]
        },
        {
          "code_ligne": "L1B", "nom": "Ligne N°1B",
          "depart": "Cité Verte de Belleville", "terminus": "Place Tiéfo Amoro",
          "arrets": ["Cité Verte de Belleville", "INSSA", "Lycée Cheick Anta Diop III", "Complexe Scolaire Carmel", "Pharmacie Hayat (Secteur 21)", "Stade Général Aboubacar Sangoulé Lamizana", "SNC / Maison de la Culture", "Agence Principale SOTRACO (Secteur 22)", "Pont d'Accart-ville", "Station Shell Diaradougou", "Rond-point du Paysan", "Monument de la CAF", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L_NASSO", "nom": "Ligne Dindéresso / Nasso",
          "depart": "Place Tiéfo AMORO", "terminus": "Université Nazi Boni de Nasso",
          "arrets": ["Place Tiéfo Amoro", "BCEAO", "Rond-point de la Nation", "Maison de la Culture / ENEP", "Pharmacie Hayat", "Stade Lamizana", "Cité Universitaire de Belleville", "Forêt Classée de Dindéresso", "Carrefour de la Guinguette", "Université Nazi Boni de Nasso"]
        },
        {
          "code_ligne": "L_BAMA", "nom": "Liaison Bama (RN9)",
          "depart": "Place Tiéfo AMORO", "terminus": "Mairie de Bama",
          "arrets": ["Place Tiéfo Amoro", "Poste de Hamdalaye", "Station Shell Diaradougou", "Gare de Dandé", "Usine ANATRANS", "Banakélédaga", "Mairie de Bama"]
        },
        {
          "code_ligne": "L_KOUMI", "nom": "Liaison Koumi (RN9)",
          "depart": "Grand Séminaire Saint-Pierre-Claver de Koumi", "terminus": "Place Tiéfo AMORO",
          "arrets": ["Grand Séminaire de Koumi", "RN9", "Secteur 21 Belleville", "Grand Marché", "Avenue de la Révolution", "Place Tiéfo Amoro"]
        },
        {
          "code_ligne": "L_SOUMOUSSO", "nom": "Ligne  Sumousso",
          "depart": "Place Tiéfo AMORO", "terminus": "Somosso ",
          "arrets": ["Place Tiéfo Amoro", "Sortie Bama / RN9", "Carrefour  Somosso"]
        },
        {
          "code_ligne": "L_SATIRI", "nom": "Ligne Satiri",
          "depart": "Place Tiéfo Amoro", "terminus": "Satiri (Centre / Mairie)",
          "arrets": ["Place Tiéfo Amoro (Centre-ville, face à la gare Sitarail)", "Boulevard de l'Indépendance (Zone administrative)", "Rond-point de la Nation", "Avenue du Général de Gaulle", "Secteur 14 / Zone Industrielle", "Barrière de contrôle RN10 (Sortie Nord-Est de Bobo)", "Village de Léguéma", "Village de Sala", "Satiri (Centre / Mairie)"]
        }
      ]
    };

    function chercher() {
      let motCle = document.getElementById('recherche').value.toLowerCase().trim();
      let zoneResultats = document.getElementById('resultats');
      zoneResultats.innerHTML = '';

      if (motCle === '') {
        zoneResultats.innerHTML = '<p>Tapez un mot-clé pour lancer la recherche.</p>';
        return;
      }

      let trouvailles = 0;

      donneesSotraco.lignes.forEach(ligne => {
        let correspondance = ligne.nom.toLowerCase().includes(motCle) ||
          ligne.code_ligne.toLowerCase().includes(motCle) ||
          ligne.depart.toLowerCase().includes(motCle) ||
          ligne.terminus.toLowerCase().includes(motCle);

        let arretsFiltres = ligne.arrets.filter(a => a.toLowerCase().includes(motCle));

        if (correspondance || arretsFiltres.length > 0) {
          trouvailles++;
          let carte = document.createElement('div');
          carte.className = 'carte';

          let listeArretsHTML = ligne.arrets.map(a => {
            return a.toLowerCase().includes(motCle) ? `<span class="surligne">${a}</span>` : a;
          }).join(' → ');

          carte.innerHTML = `
            <div class="titre-ligne">${ligne.nom} (${ligne.code_ligne})</div>
            <p><strong>Trajet :</strong> ${ligne.depart} ↔ ${ligne.terminus}</p>
            <div class="arrets"><strong>Arrêts :</strong> ${listeArretsHTML}</div>
          `;

          zoneResultats.appendChild(carte);
        }
      });

      if (trouvailles === 0) {
        zoneResultats.innerHTML = '<p>Aucun résultat trouvé.</p>';
      }
    }
 chercher();                       